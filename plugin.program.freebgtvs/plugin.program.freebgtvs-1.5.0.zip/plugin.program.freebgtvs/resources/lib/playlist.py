# -*- coding: utf8 -*-
import os
import re
import sys
import xbmc
import xbmcaddon
import json
import time
import requests
from kodibgcommon.logging import log_info,log_error
import importlib

importlib.reload(sys)  

class Playlist:
  name = 'playlist.m3u'
  channels = []
  raw_m3u = None
  append = True
  
  def __init__(self, name = ''):
    if name != '':
      self.name = name
  
  def save(self, path, static=True):
    __name = self.name if static else 'dynamic_%s' % self.name
    file_path = os.path.join(path, __name)
    log_info("Запазване на плейлистата: %s " % file_path)
    if os.path.exists(path):
      with open(file_path, 'w', encoding='utf-8') as f:
        f.write(self.to_string(static))
  
  def concat(self, new_m3u, append = True, raw = True):
    if raw: #TODO implement parsing playlists
      self.append = append
      with open(new_m3u, 'r', encoding='utf-8') as f:
        self.raw_m3u = f.read().replace('#EXTM3U', '')
  
  def to_string(self, static):
    output = ''
    for c in self.channels:
      output += c.to_string(static)
      
    if self.raw_m3u != None:
      if self.append:
        output += self.raw_m3u
      else:
        output = self.raw_m3u + output
    
    return '#EXTM3U\n' + output

class Category:
	def __init__(self, id, title):
		self.id = id
		self.title = title
    
class Channel:

  playpath = None
  static_playpath = None
  
  def __init__(self, attr):
    self.id = attr[0]
    self.name = attr[1]
    self.logo = attr[2]
    self.ordering = attr[3]
    self.enabled = attr[4] == 1
    self.category = attr[5]
    self.epg_id = attr[6]
    #self.is_radio = 
    
  def to_string(self, static=True):
    is_radio = True if self.category == 'Радио' else False
    __playpath = self.static_playpath if static else self.playpath
    output = '#EXTINF:-1 radio="%s" tvg-shift=0 group-title="%s" tvg-logo="%s" tvg-id="%s",%s\n' % (is_radio, self.category, self.logo, self.epg_id, self.name)
    output += '%s\n' % __playpath
    return output 
 
class Stream:
  def __init__(self, **attr):
    self.id = attr.get("id")
    log_info("stream id=%s" % self.id)
    self.url = attr.get("stream_url")
    log_info("url=%s" % self.url)
    self.page_url = attr.get("page_url")
    self.comment = attr.get("comment")
    self.channel_id = attr.get("channel_id")
    log_info("channel_id=%s" % self.channel_id)
    self.enabled = attr.get("enabled") == 1
    self.player_url = attr.get("player_url")
    self.user_agent = False if attr.get("user_agent") == None else attr.get("user_agent")
    self.regex = False if attr.get("regex") == None else attr.get("regex")
    if self.url == None or self.url == "":
      log_info("Resolving playpath url from %s" % self.player_url)
      self.url = self.resolve()
    # if self.url is not None and self.user_agent: 
     # self.url += '|User-Agent=%s' % self.user_agent
    # if self.url is not None and self.page_url:
     # self.url += '&Referer=%s' % self.page_url
    log_info("Stream final playpath: %s" % self.url)

  def resolve(self):
    stream = None
    s = requests.session()
    headers = {'User-agent': str(self.user_agent), 'Referer':str(self.page_url)}
    
    self.player_url = self.player_url.replace("{timestamp}", str(time.time() * 100))
    log_info(self.player_url)
    r = s.get(self.player_url, headers=headers, verify=True)
    #log("Body before replacing escape backslashes: " + r.text, 4)
    body = r.text.replace('\\/', '/').replace("\\\"", "\"")
    #log("Body after replacing escape backslashes: " + body, 4)
    regex = self.regex if self.regex else '(//.*?\.m3u.*?)[\s\'"]{1}'
    log_info("Regex used: %s" % regex)
    m = re.compile(regex).findall(body)
    #m = re.compile('(//.*\.m3u.*?)[\s\'"]+').findall(body)
    if len(m) > 0:
      if self.player_url.startswith("https"):
        stream = "https:" + m[0]
      elif self.player_url.startswith("http"):
        stream = "http:" + m[0]
      log_info('Намерени %s съвпадения в %s' % (len(m), self.player_url))
      log_info('Извлечен видео поток %s' % stream)
    else:
      log_error("Не са намерени съвпадения за m3u")
      
    return stream
