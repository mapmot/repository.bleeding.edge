Plugin can be installed via repo:
https://github.com/kodi1/kodi1.github.io/releases/download/v0.0.1/repo.bg.plugins.zip
